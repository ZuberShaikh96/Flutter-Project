import 'package:flutter/material.dart';
import './models/category.dart';

const DUMMY_CATEGORIES = const [
  Category(
    id:'1',
    title: 'First',
    color:Colors.purple,
  ),
  Category(
    id:'2',
    title: 'Second',
    color:Colors.purple,
  ),
  Category(
    id:'3',
    title: 'Third',
    color:Colors.purple,
  ),
  Category(
    id:'4',
    title: 'Fourth',
    color:Colors.purple,
  ),
  Category(
    id:'4',
    title: 'Fourth',
    color:Colors.purple,
  ),
];